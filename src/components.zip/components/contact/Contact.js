import React from 'react';

const Contact = () => (
  <section id="contact_area">
    {/* Contact form and info go here */}
    <div>Contact Me</div>
  </section>
);

export default Contact;
