import React from 'react';

const About = () => (
  <section id="about">
    {/* About content goes here */}
    <div>About Of Web Developer</div>
  </section>
);

export default About;
