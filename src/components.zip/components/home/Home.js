import React from 'react';

function Home() {
  return (
    <div id="container">
      <section id="home">
        <div></div>
      </section>
      <div id="header">

        <div className="navbar">
          <ul>
            <li><a className="active" href="#home">home</a></li>
            <li><a href="#portfolio">portfolio</a></li>
            <li><a href="#about">about</a></li>
            <li><a href="#contact_area">contact</a></li>
          </ul>
        </div>


        <div className="welcome_note">
          <img className="owner_img" src="https://images.pexels.com/photos/842567/pexels-photo-842567.jpeg?auto=compress&cs=tinysrgb&h=350" alt="Lorens Bappy Mondal" width="200" height="200" />
          <h3 className="owner_nam">Mr. Lorens Bappy Mondal</h3>
          <h5 className="owner_designation">Web Designer and Developer</h5>
          <h1 className="welcome_note_title">Welcome to My Portfolio Page</h1>
          <p className="welcome_content">Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim velit porro nam magnam nulla voluptatem debitis, laborum, voluptas, reiciendis quis dolorem rem exercitationem nihil repellat modi eveniet consequatur pariatur officia? Iure illum iste incidunt autem odit iusto assumenda! Quis, dolorum iste. Illo ab optio unde consectetur iusto id sint alias.</p>
          <button className="learn_more">Learn More</button>
          <button className="contact">Contact</button>
        </div>
      </div>

      <section id="portfolio">
        <div className="row ">*****************************************************
          <div className="portfolio_header">
            <h3 className="portfolio_title" style={{ fontSize: '35px' }}>My Portfolio Gallery</h3>
            <p className="portfolio_content">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Possimus, sint.</p>
            <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
          </div>

        </div>
      </section>

      <section id="about">
        <div className="row">
          <h3 className="about_title">About Of Web Developer</h3>
          <div className="about_content">
            <img src="https://images.pexels.com/photos/684385/pexels-photo-684385.jpeg?auto=compress&cs=tinysrgb&h=350" alt="About Image" width="500" height="300" />
            <p className="brief">
              I am Mr. Lorens Bappy Mondal. I am a Web Developer and learner of <a href="https://www.freecodecamp.org" title="www.freecodecamp.org">Free Code Camp</a>. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente ipsum, in eaque enim nesciunt mollitia architecto reprehenderit dicta aliquam doloremque quisquam beatae ad nostrum consequatur sequi eius tempora repellendus exercitationem veniam veritatis quibusdam corporis repudiandae impedit? Ipsa tempore minima ullam veniam, ratione consequuntur nobis laborum iste nostrum enim, maxime asperiores! Sapiente ipsum, in eaque enim nesciunt mollitia architecto reprehenderit dicta aliquam doloremque quisquam beatae ad nostrum consequatur sequi eius tempora repellendus exercitationem veniam veritatis quibusdam corporis repudiandae impedit? Ipsa tempore minima ullam veniam.<br />
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente ipsum, in eaque enim nesciunt mollitia architecto reprehenderit dicta aliquam doloremque quisquam beatae ad nostrum consequatur sequi eius tempora repellendus exercitationem veniam veritatis quibusdam corporis repudiandae impedit? Ipsa tempore minima ullam veniam, ratione consequuntur nobis laborum iste nostrum enim, maxime asperiores! Sapiente ipsum, in eaque enim nesciunt mollitia architecto reprehenderit dicta aliquam doloremque quisquam beatae ad nostrum consequatur sequi eius tempora repellendus exercitationem veniam veritatis quibusdam corporis repudiandae impedit? Ipsa tempore minima ullam veniam.
            </p>
          </div>
          <div className="skill">
            <h1 className="skill_title">Skill</h1>

            <p>Photoshop</p>
            <div className="skill_bar">
              <div className="skills photoshop">95%</div>
            </div>
            <p>HTML</p>
            <div className="skill_bar">
              <div className="skills html">90%</div>
            </div>

            <p>CSS</p>
            <div className="skill_bar">
              <div className="skills css">85%</div>
            </div>

            <p>JavaScript</p>
            <div className="skill_bar">
              <div className="skills js">70%</div>
            </div>

            <p>PHP</p>
            <div className="skill_bar">
              <div className="skills php">60%</div>
            </div>

            <p>MySql</p>
            <div className="skill_bar">
              <div className="skills mysql">45%</div>
            </div>

          </div>
        </div>
      </section>

      <section id="contact_area">
        <div className="row">
          <div className="column2">
            <div className="contfrm">
              <h3 className="contact_title">Contact Me</h3>
              <form action="#" name="Contact_Form">
                <label className="input_title" htmlFor="fname">Full Name</label><br />
                <input type="text" name="fname" placeholder="Type Your Full Name" /><br />
                <label className="input_title" htmlFor="email">Email</label><br />
                <input type="text" name="email" placeholder="Type Your Email Address" /><br />
                <label className="input_title" htmlFor="message">Message</label><br />
                <textarea type="text" name="message" id="" cols="60" rows="10" placeholder="Type Your Message..."></textarea><br />

                <label className="radio_container">Buyer
                  <input type="radio" name="radio" id="" value="Buyer" checked />
                  <span className="checkmark"></span>
                </label>

                <label className="radio_container">Developer
                  <input type="radio" name="radio" id="" value="Developer" />
                  <span className="checkmark"></span>
                </label>

                <label className="radio_container">Student
                  <input type="radio" name="radio" id="" value="Student" />
                  <span className="checkmark"></span>
                </label>

                <label className="radio_container">Others
                  <input type="radio" name="radio" id="" value="Others" />
                  <span className="checkmark"></span>
                </label>
                <br />
                <input type="submit" name="send" value="Send Message" id="" />
              </form>
            </div>
          </div>
        </div>
      </section>


      <footer id="footer_area">
        <div className="row">
          <div className="footer_navbar">
            <ul className="footer_menu">
              <li><a href="index.html">Home</a></li>
              <li><a href="#portfolio">Portfolio</a></li>
              <li><a href="#about">About</a></li>
              <li><a href="#contact">Contact</a></li>
            </ul>
          </div>

        </div>
      </footer>
    </div>

  );
}

export default Home;
