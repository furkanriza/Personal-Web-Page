import React from 'react';

const Footer = () => (
  <footer id="footer_area">
    {/* Footer content goes here */}
    <div>Copyright & Design By Mr. Lorens Bappy Mondal</div>
  </footer>
);

export default Footer;
